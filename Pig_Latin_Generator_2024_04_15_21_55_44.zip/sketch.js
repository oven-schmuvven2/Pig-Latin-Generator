let img;
function preload() {
  img = loadImage("https://media.discordapp.net/attachments/887489763257503754/1184266339750252604/image.png?ex=658b58fa&is=6578e3fa&hm=3d89387a08cf66c192be70a20c430783c39dbe9eb75466e0f1ed972321b3c79f&=&format=webp&quality=lossless&width=1200&height=1200");
}

function setup() {
  createCanvas(600, 600);
}

function encode(phrase){
  var phrase1 = phrase.split(" ")
  var finalarray = []
  for(var i = 0; i<phrase1.length;i++){
    var word = phrase1[i]
    var firstletter = word[0]
    var secondletter = "NA"
    if(word[1] == "h" && word[0] == "t" || word[1] == "h" && word[0] == "s" || word[1] == "h" && word[0] == "w" || word[1] == "h" && word[0] == "c" || word[1] == "h" && word[0] == "p"){
      secondletter = word[1]
      word = word.replace(firstletter,"")
      word = word.replace(secondletter, "")
      word = word + firstletter + secondletter + "ay"
      finalarray.push(word)
    } else if(firstletter == "a" || firstletter == "e" || firstletter == "i" || firstletter == "o" || firstletter == "u") {
      word = word + "way"
      finalarray.push(word)
    } else {
      word = word.replace(firstletter,"")
      word = word + firstletter + "ay"
      finalarray.push(word)
    }
  }
  var finalphrase = finalarray.join(" ")
  alert(finalphrase)
}



function decode(prompt) {
  var phrase1 = prompt.split(" ")
  var finalarray = []
  for(var i = 0; i<phrase1.length;i++){
    var word = phrase1[i]
    word = word.split('');
    word.pop()
    word.pop()
    var letter = word[word.length-1]
    word.pop()
    word = word.join('');
    word = letter + word
    finalarray.push(word)
  }
  var finalphrase = finalarray.join(" ")
  alert(finalphrase)
}

function draw() {
  background(220);
  image(img, 0, 0, 600, 600);
}

var choice = Number(prompt("put 1 if you want to encode and 2 if you want to decode."))
var phrase = prompt("put a phrase here to be encoded into pig latin pretty please")
if(choice == 1){
  encode(phrase)
}
if(choice == 2){
  decode(phrase)
}